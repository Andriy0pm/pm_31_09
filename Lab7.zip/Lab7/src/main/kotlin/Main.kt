package main.kotlin

import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import main.kotlin.model.Location
import main.kotlin.ui.MainScreen
import main.kotlin.ui.HistoryPanel
import main.kotlin.util.LocalStorage
import androidx.compose.material.MaterialTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp



@Composable
@Preview
fun App() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Поточна погода", "Історія погодних даних")

    // Стан для історії
    val history = remember { mutableStateListOf<Location>() }

    // Помилки
    var error by remember { mutableStateOf<String?>(null) }

    // Завантаження історії при старті
    LaunchedEffect(Unit) {
        history.addAll(LocalStorage.loadHistory())
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Weather Info App") })
            },
            content = {
                Column {
                    TabRow(selectedTabIndex = selectedTab) {
                        tabTitles.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                text = { Text(title) }
                            )
                        }
                    }

                    when (selectedTab) {
                        0 -> MainScreenWrapper(history)
                        1 -> HistoryPanel(history = history) { errorMsg -> error = errorMsg }
                    }

                    error?.let {
                        Text(it, color = MaterialTheme.colors.error, modifier = androidx.compose.ui.Modifier.padding(16.dp))
                    }
                }
            }
        )
    }
}

@Composable
fun MainScreenWrapper(history: MutableList<Location>) {
    // Обгортка MainScreen для доступу до історії та збереження змін
    MainScreenWithHistory(
        history = history,
        onHistoryUpdated = {
            LocalStorage.saveHistory(history)
        }
    )
}

@Composable
fun MainScreenWithHistory(
    history: MutableList<Location>,
    onHistoryUpdated: () -> Unit
) {
    val historyState = remember { mutableStateListOf<Location>().apply { addAll(history) } }

    MainScreenCustomHistory(
        history = historyState,
        onAddLocation = { location ->
            if (historyState.none { it.lat == location.lat && it.lon == location.lon }) {
                historyState.add(location)
                history.clear()
                history.addAll(historyState)
                onHistoryUpdated()
            }
        }
    )
}

@Composable
fun MainScreenCustomHistory(
    history: MutableList<Location>,
    onAddLocation: (Location) -> Unit
) {
    // Перевикористання MainScreen з підключенням історії та додаванням
    main.kotlin.ui.MainScreenWithExternalHistory(history, onAddLocation)
}

fun main() = application {
    Window(onCloseRequest = ::exitApplication, title = "Weather Info") {
        MaterialTheme {
            Surface {
                MainScreen()
            }
        }
        App()
    }
}
