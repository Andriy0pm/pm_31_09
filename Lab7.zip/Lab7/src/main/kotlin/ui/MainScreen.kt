package main.kotlin.ui

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.VerticalScrollbar
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.rememberScrollbarAdapter
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import main.kotlin.api.WeatherApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import main.kotlin.model.CurrentWeatherResponse
import main.kotlin.model.Location

@Composable
fun MainScreen() {
    var latitude by remember { mutableStateOf("") }
    var longitude by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var currentWeather by remember { mutableStateOf<CurrentWeatherResponse?>(null) }
    val history = remember { mutableStateListOf<Location>() }

    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {

        Text("Пошук погоди за координатами", style = MaterialTheme.typography.h6)

        Row(modifier = Modifier.padding(top = 8.dp)) {
            OutlinedTextField(
                value = latitude,
                onValueChange = { latitude = it },
                label = { Text("Широта") },
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            )
            OutlinedTextField(
                value = longitude,
                onValueChange = { longitude = it },
                label = { Text("Довгота") },
                modifier = Modifier.weight(1f)
            )
        }

        Button(
            onClick = {
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        val lat = latitude.toDouble()
                        val lon = longitude.toDouble()
                        val weather = WeatherApiService.getCurrentWeather(lat, lon)
                        currentWeather = weather
                        if (history.none { it.lat == lat && it.lon == lon }) {
                            history.add(weather.location)
                        }
                        errorMessage = null
                    } catch (e: Exception) {
                        errorMessage = "Помилка: ${e.message}"
                    }
                }
            },
            modifier = Modifier.padding(top = 12.dp)
        ) {
            Text("Пошук")
        }

        errorMessage?.let {
            Text(it, color = MaterialTheme.colors.error, modifier = Modifier.padding(top = 8.dp))
        }

        currentWeather?.let { weather ->
            WeatherDetails(weather)
        }

        Divider(modifier = Modifier.padding(vertical = 12.dp))

        Text("Історія запитів", style = MaterialTheme.typography.subtitle1)

        Box(modifier = Modifier.fillMaxHeight().padding(top = 8.dp)) {
            Row {
                Column(
                    modifier = Modifier
                        .verticalScroll(scrollState)
                        .weight(1f)
                ) {
                    history.forEach { location ->
                        Button(
                            onClick = {
                                coroutineScope.launch(Dispatchers.IO) {
                                    try {
                                        val weather = WeatherApiService.getCurrentWeather(location.lat, location.lon)
                                        currentWeather = weather
                                        errorMessage = null
                                    } catch (e: Exception) {
                                        errorMessage = "Помилка: ${e.message}"
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Text("${location.name}, ${location.country} (${location.lat}, ${location.lon})")
                        }
                    }
                }

                VerticalScrollbar(
                    adapter = rememberScrollbarAdapter(scrollState),
                    modifier = Modifier.fillMaxHeight()
                )
            }
        }
    }
}

@Composable
fun MainScreenWithExternalHistory(
    history: MutableList<Location>,
    onAddLocation: (Location) -> Unit
) {
    var latitude by remember { mutableStateOf("") }
    var longitude by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var currentWeather by remember { mutableStateOf<main.kotlin.model.CurrentWeatherResponse?>(null) }

    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {

        Text("Пошук погоди за координатами", style = MaterialTheme.typography.h6)

        Row(modifier = Modifier.padding(top = 8.dp)) {
            OutlinedTextField(
                value = latitude,
                onValueChange = { latitude = it },
                label = { Text("Широта") },
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            )
            OutlinedTextField(
                value = longitude,
                onValueChange = { longitude = it },
                label = { Text("Довгота") },
                modifier = Modifier.weight(1f)
            )
        }

        Button(
            onClick = {
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        val lat = latitude.toDouble()
                        val lon = longitude.toDouble()
                        val weather = main.kotlin.api.WeatherApiService.getCurrentWeather(lat, lon)
                        currentWeather = weather
                        onAddLocation(weather.location)
                        errorMessage = null
                    } catch (e: Exception) {
                        errorMessage = "Помилка: ${e.message}"
                    }
                }
            },
            modifier = Modifier.padding(top = 12.dp)
        ) {
            Text("Пошук")
        }

        errorMessage?.let {
            Text(it, color = MaterialTheme.colors.error, modifier = Modifier.padding(top = 8.dp))
        }

        currentWeather?.let { weather ->
            main.kotlin.ui.WeatherDetails(weather)
        }

        Divider(modifier = Modifier.padding(vertical = 12.dp))

        Text("Історія запитів", style = MaterialTheme.typography.subtitle1)

        Box(modifier = Modifier.fillMaxHeight().padding(top = 8.dp)) {
            Row {
                Column(
                    modifier = Modifier
                        .verticalScroll(scrollState)
                        .weight(1f)
                ) {
                    history.forEach { location ->
                        Button(
                            onClick = {
                                coroutineScope.launch(Dispatchers.IO) {
                                    try {
                                        val weather = main.kotlin.api.WeatherApiService.getCurrentWeather(location.lat, location.lon)
                                        currentWeather = weather
                                        errorMessage = null
                                    } catch (e: Exception) {
                                        errorMessage = "Помилка: ${e.message}"
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Text("${location.name}, ${location.country} (${location.lat}, ${location.lon})")
                        }
                    }
                }

                VerticalScrollbar(
                    adapter = rememberScrollbarAdapter(scrollState),
                    modifier = Modifier.fillMaxHeight()
                )
            }
        }
    }
}
