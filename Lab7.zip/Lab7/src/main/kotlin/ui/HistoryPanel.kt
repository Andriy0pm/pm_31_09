package main.kotlin.ui

import androidx.compose.foundation.VerticalScrollbar
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.rememberScrollbarAdapter
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import main.kotlin.api.WeatherApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import main.kotlin.model.HistoricalWeatherResponse
import main.kotlin.model.Location

@Composable
fun HistoryPanel(
    history: List<Location>,
    onError: (String) -> Unit
) {
    var selectedLocation by remember { mutableStateOf<Location?>(null) }
    var historicalData by remember { mutableStateOf<List<HistoricalWeatherResponse>>(emptyList()) }

    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Історичні погодні дані (останні 14 днів)", style = MaterialTheme.typography.h6)

        Row(modifier = Modifier.fillMaxSize()) {
            // Список міст
            Column(modifier = Modifier.weight(1f).verticalScroll(scrollState)) {
                history.forEach { location ->
                    Button(
                        onClick = {
                            selectedLocation = location
                            coroutineScope.launch(Dispatchers.IO) {
                                try {
                                    val data = WeatherApiService.getHistoricalWeather(location.lat, location.lon)
                                    historicalData = data
                                } catch (e: Exception) {
                                    onError("Не вдалося завантажити історичні дані: ${e.message}")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Text("${location.name}, ${location.country}")
                    }
                }
            }

            VerticalScrollbar(
                adapter = rememberScrollbarAdapter(scrollState),
                modifier = Modifier.fillMaxHeight().padding(start = 4.dp)
            )

            // Деталі погоди за 14 днів
            Column(modifier = Modifier.weight(2f).padding(start = 16.dp)) {
                selectedLocation?.let {
                    Text("Дані для: ${it.name}, ${it.country}", style = MaterialTheme.typography.subtitle1)

                    Spacer(modifier = Modifier.height(8.dp))

                    if (historicalData.isNotEmpty()) {
                        historicalData.forEach { dayResponse ->
                            dayResponse.forecast.forecastday.forEach { forecastDay ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    elevation = 4.dp
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("Дата: ${forecastDay.date}", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                        Text("Середня температура: ${forecastDay.day.avgtemp_c} °C")
                                        Text("Середня вологість: ${forecastDay.day.avghumidity} %")
                                        Text("Опади: ${forecastDay.day.totalprecip_mm} мм")
                                    }
                                }
                            }
                        }
                    } else {
                        Text("Оберіть місце для перегляду історії.")
                    }
                } ?: Text("Оберіть місце зі списку.")
            }
        }
    }
}
