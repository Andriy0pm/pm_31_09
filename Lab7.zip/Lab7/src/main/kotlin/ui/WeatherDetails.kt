package main.kotlin.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import main.kotlin.model.CurrentWeatherResponse
import androidx.compose.ui.graphics.asImageBitmap
import java.awt.image.BufferedImage
import androidx.compose.ui.graphics.asImageBitmap
import java.awt.Image as AwtImage
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import org.jetbrains.skia.Image
import java.net.URL
import javax.imageio.ImageIO
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO.write



@Composable
fun WeatherDetails(weather: CurrentWeatherResponse) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Text(
            text = "Поточна погода в ${weather.location.name}, ${weather.location.country}",
            style = MaterialTheme.typography.h6
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Температура: ${weather.current.temp_c} °C", fontSize = 16.sp)
                Text("Тиск: ${weather.current.pressure_mb} мбар", fontSize = 16.sp)
                Text("Вологість: ${weather.current.humidity}%", fontSize = 16.sp)
                Text("Опади: ${weather.current.precip_mm} мм", fontSize = 16.sp)
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(start = 16.dp)
            ) {
                Text(
                    text = weather.current.condition.text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                WeatherIcon(iconUrl = "https:${weather.current.condition.icon}")
            }
        }
    }
}

@Composable
fun WeatherIcon(iconUrl: String) {
    val imageBitmap = remember(iconUrl) {
        try {
            val url = URL(iconUrl)
            val bufferedImage: BufferedImage = ImageIO.read(url)

            // Конвертуємо BufferedImage в ByteArray
            val outputStream = ByteArrayOutputStream()
            ImageIO.write(bufferedImage, "png", outputStream)
            val byteArray = outputStream.toByteArray()

            // Створюємо ImageBitmap через Skia Image
            val skiaImage = Image.makeFromEncoded(byteArray)
            skiaImage.toComposeImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    imageBitmap?.let {
        androidx.compose.foundation.Image(
            bitmap = it,
            contentDescription = "Icon",
            modifier = Modifier.size(64.dp),
            contentScale = ContentScale.Fit
        )
    }
}




