package main.kotlin.util

import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import main.kotlin.model.Location
import java.io.File

object LocalStorage {
    private val json = Json { prettyPrint = true }
    private val filePath = "${System.getProperty("user.home")}/weather_history.json"

    // Зберегти історію запитів у файл
    fun saveHistory(history: List<Location>) {
        try {
            val jsonData = json.encodeToString(history)
            File(filePath).writeText(jsonData)
        } catch (e: Exception) {
            println("Помилка при збереженні історії: ${e.message}")
        }
    }

    // Завантажити історію запитів із файлу
    fun loadHistory(): List<Location> {
        return try {
            val file = File(filePath)
            if (file.exists()) {
                val jsonData = file.readText()
                json.decodeFromString(jsonData)
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            println("Помилка при завантаженні історії: ${e.message}")
            emptyList()
        }
    }

    // Очистити історію (видалити файл)
    fun clearHistory() {
        try {
            val file = File(filePath)
            if (file.exists()) file.delete()
        } catch (e: Exception) {
            println("Помилка при очищенні історії: ${e.message}")
        }
    }
}
