package main.kotlin.api

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import main.kotlin.model.*
import java.time.LocalDate

object WeatherApiService {
    private const val BASE_URL = "https://api.weatherapi.com/v1"
    private const val API_KEY = "7856db6277594cb78a200702250606" // 🔐 Замінити на свій ключ

    private val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    suspend fun getCurrentWeather(lat: Double, lon: Double): CurrentWeatherResponse {
        val response = client.get("$BASE_URL/current.json") {
            parameter("key", API_KEY)
            parameter("q", "$lat,$lon")
        }
        return response.body()
    }

    suspend fun getHistoricalWeather(lat: Double, lon: Double, days: Int = 14): List<HistoricalWeatherResponse> {
        val today = LocalDate.now()
        val result = mutableListOf<HistoricalWeatherResponse>()

        for (i in 0 until days) {
            val date = today.minusDays(i.toLong())
            val response = client.get("$BASE_URL/history.json") {
                parameter("key", API_KEY)
                parameter("q", "$lat,$lon")
                parameter("dt", date.toString())
            }
            result.add(response.body())
        }
        return result
    }
}
