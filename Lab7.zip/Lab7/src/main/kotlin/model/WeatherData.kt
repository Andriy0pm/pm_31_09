package main.kotlin.model

import kotlinx.serialization.Serializable

@Serializable
data class CurrentWeatherResponse(
    val location: Location,
    val current: Current
)

@Serializable
data class Location(
    val name: String,
    val region: String,
    val country: String,
    val lat: Double,
    val lon: Double
)

@Serializable
data class Current(
    val temp_c: Double,
    val pressure_mb: Double,
    val humidity: Int,
    val precip_mm: Double,
    val condition: Condition
)

@Serializable
data class Condition(
    val text: String,
    val icon: String
)

@Serializable
data class HistoricalWeatherResponse(
    val location: Location,
    val forecast: Forecast
)

@Serializable
data class Forecast(
    val forecastday: List<ForecastDay>
)

@Serializable
data class ForecastDay(
    val date: String,
    val day: Day
)

@Serializable
data class Day(
    val maxtemp_c: Double,
    val mintemp_c: Double,
    val avgtemp_c: Double,
    val avghumidity: Double,
    val totalprecip_mm: Double
)
