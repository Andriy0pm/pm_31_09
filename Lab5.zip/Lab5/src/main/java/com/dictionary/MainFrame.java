package com.dictionary;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class MainFrame extends JFrame {
    private VehicleRepository repo;
    private JTable table;
    private DefaultTableModel tableModel;

    public MainFrame() {
        repo = new VehicleRepository();
        repo.load();

        setTitle("Vehicle Rental System");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new Object[]{"ID", "Type", "Brand", "Price", "Available"}, 0);
        table = new JTable(tableModel);
        refreshTable(repo.getVehicles());
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel controlPanel = new JPanel();

        JButton addBtn = new JButton("Add");
        JButton deleteBtn = new JButton("Delete");
        JButton filterBtn = new JButton("Filter");
        JButton updateBtn = new JButton("Update");
        JButton rentBtn = new JButton("Rent");
        JButton returnBtn = new JButton("Return");

        controlPanel.add(addBtn);
        controlPanel.add(deleteBtn);
        controlPanel.add(filterBtn);
        controlPanel.add(updateBtn);
        controlPanel.add(rentBtn);
        controlPanel.add(returnBtn);

        add(controlPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addVehicleDialog());
        deleteBtn.addActionListener(e -> deleteSelectedVehicle());

        filterBtn.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(this, "Max price:");
            if (input != null && !input.trim().isEmpty()) {
                try {
                    double max = Double.parseDouble(input.trim());
                    refreshTable(repo.filterByPrice(max));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        updateBtn.addActionListener(e -> refreshTable(repo.getVehicles()));

        rentBtn.addActionListener(e -> {
            List<Vehicle> availableVehicles = repo.getVehicles().stream()
                    .filter(Vehicle::isAvailable)
                    .collect(Collectors.toList());

            if (availableVehicles.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No available vehicles.");
                return;
            }

            Vehicle selected = (Vehicle) JOptionPane.showInputDialog(this, "Select vehicle to rent:",
                    "Rent", JOptionPane.PLAIN_MESSAGE, null,
                    availableVehicles.toArray(), availableVehicles.get(0));

            if (selected != null) {
                selected.setAvailable(false);
                repo.save();
                refreshTable(repo.getVehicles());
            }
        });

        returnBtn.addActionListener(e -> {
            List<Vehicle> rented = repo.getVehicles().stream()
                    .filter(v -> !v.isAvailable())
                    .collect(Collectors.toList());

            if (rented.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No rented vehicles.");
                return;
            }

            Vehicle selected = (Vehicle) JOptionPane.showInputDialog(this, "Select vehicle to return:",
                    "Return", JOptionPane.PLAIN_MESSAGE, null,
                    rented.toArray(), rented.get(0));

            if (selected != null) {
                selected.setAvailable(true);
                repo.save();
                refreshTable(repo.getVehicles());
            }
        });

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                repo.save();
            }
        });
    }

    private void refreshTable(List<Vehicle> vehicles) {
        tableModel.setRowCount(0);
        for (Vehicle v : vehicles) {
            tableModel.addRow(new Object[]{v.getId(), v.getType(), v.getBrand(), v.getRentPricePerDay(), v.isAvailable()});
        }
    }

    private void addVehicleDialog() {
        String[] types = {"Car", "Truck", "Special Equipment"};
        String type = (String) JOptionPane.showInputDialog(this, "Select type:", "Type",
                JOptionPane.QUESTION_MESSAGE, null, types, types[0]);

        if (type == null) return;

        String brand = JOptionPane.showInputDialog("Brand:");
        if (brand == null || brand.trim().isEmpty()) return;

        String priceStr = JOptionPane.showInputDialog("Price per day:");
        if (priceStr == null || priceStr.trim().isEmpty()) return;

        double price;
        try {
            price = Double.parseDouble(priceStr.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid price format.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String id = UUID.randomUUID().toString();
        boolean available = true;

        Vehicle v = switch (type) {
            case "Car" -> new Car(id, brand, price, available);
            case "Truck" -> new Truck(id, brand, price, available);
            default -> new SpecialEquipment(id, brand, price, available);
        };

        repo.addVehicle(v);
        refreshTable(repo.getVehicles());
    }

    private void deleteSelectedVehicle() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            String id = (String) tableModel.getValueAt(row, 0);
            repo.removeVehicle(id);
            refreshTable(repo.getVehicles());
        }
    }
}
