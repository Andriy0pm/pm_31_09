package com.dictionary;

import java.io.Serializable;

public abstract class Vehicle implements Serializable {
    protected String id;
    protected String brand;
    protected double rentPricePerDay;
    protected boolean isAvailable;

    public Vehicle(String id, String brand, double rentPricePerDay, boolean isAvailable) {
        this.id = id;
        this.brand = brand;
        this.rentPricePerDay = rentPricePerDay;
        this.isAvailable = isAvailable;
    }

    public abstract String getType();

    public String getId() { return id; }
    public String getBrand() { return brand; }
    public double getRentPricePerDay() { return rentPricePerDay; }
    public boolean isAvailable() { return isAvailable; }

    public void setBrand(String brand) { this.brand = brand; }
    public void setRentPricePerDay(double price) { this.rentPricePerDay = price; }
    public void setAvailable(boolean available) { this.isAvailable = available; }

    @Override
    public String toString() {
        return String.format("[%s] %s - $%.2f/day", id, brand, rentPricePerDay);
    }

}
