package com.dictionary;

public class SpecialEquipment extends Vehicle {
    public SpecialEquipment(String id, String brand, double rentPricePerDay, boolean isAvailable) {
        super(id, brand, rentPricePerDay, isAvailable);
    }

    @Override
    public String getType() {
        return "Special Equipment";
    }
}
