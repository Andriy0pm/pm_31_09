package com.dictionary;

public class Truck extends Vehicle {
    public Truck(String id, String brand, double rentPricePerDay, boolean isAvailable) {
        super(id, brand, rentPricePerDay, isAvailable);
    }

    @Override
    public String getType() {
        return "Truck";
    }
}
