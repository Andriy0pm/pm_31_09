package com.dictionary;

import com.dictionary.Vehicle;
import java.io.*;
import java.util.*;

public class VehicleRepository {
    private List<Vehicle> vehicles = new ArrayList<>();
    private final String FILE_NAME = "vehicles.dat";

    public void load() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            vehicles = (List<Vehicle>) ois.readObject();
        } catch (Exception e) {
            vehicles = new ArrayList<>();
        }
    }

    public void save() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(vehicles);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public void addVehicle(Vehicle v) {
        vehicles.add(v);
    }

    public void removeVehicle(String id) {
        vehicles.removeIf(v -> v.getId().equals(id));
    }

    public List<Vehicle> filterByPrice(double maxPrice) {
        List<Vehicle> filtered = new ArrayList<>();
        for (Vehicle v : vehicles) {
            if (v.getRentPricePerDay() <= maxPrice) {
                filtered.add(v);
            }
        }
        return filtered;
    }
}
