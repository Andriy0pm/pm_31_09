package com.dictionary;

public class Car extends Vehicle {
    public Car(String id, String brand, double rentPricePerDay, boolean isAvailable) {
        super(id, brand, rentPricePerDay, isAvailable);
    }

    @Override
    public String getType() {
        return "Car";
    }
}