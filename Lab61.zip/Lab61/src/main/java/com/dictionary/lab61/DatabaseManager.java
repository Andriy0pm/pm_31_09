package com.dictionary.lab61;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private static final String URL = "jdbc:h2:./data/realestate";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public void initDatabase() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS PROPERTIES (
                    id IDENTITY PRIMARY KEY,
                    address VARCHAR(255),
                    rooms INT,
                    LIVING_AREA DOUBLE,
                    TOTAL_AREA DOUBLE,
                    floor INT,
                    price DOUBLE,
                    phone VARCHAR(50)
                )
            """);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addProperty(Property property) {
        String sql = "INSERT INTO PROPERTIES (address, rooms, LIVING_AREA, TOTAL_AREA, floor, price, phone) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, property.getAddress());
            pstmt.setInt(2, property.getRooms());
            pstmt.setDouble(3, property.getLivingArea());
            pstmt.setDouble(4, property.getTotalArea());
            pstmt.setInt(5, property.getFloor());
            pstmt.setDouble(6, property.getPrice());
            pstmt.setString(7, property.getPhone());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Property> getAllProperties() {
        List<Property> properties = new ArrayList<>();
        String sql = "SELECT * FROM PROPERTIES";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                properties.add(fromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return properties;
    }

    public List<Property> searchByRoomsAndPrice(int rooms, double minPrice, double maxPrice) {
        List<Property> properties = new ArrayList<>();
        String sql = "SELECT * FROM PROPERTIES WHERE rooms = ? AND price BETWEEN ? AND ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, rooms);
            pstmt.setDouble(2, minPrice);
            pstmt.setDouble(3, maxPrice);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    properties.add(fromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return properties;
    }

    public List<Property> searchByRoomsAndArea(int rooms, double area, boolean byTotal) {
        List<Property> properties = new ArrayList<>();
        String areaColumn = byTotal ? "TOTAL_AREA" : "LIVING_AREA";
        String sql = "SELECT * FROM PROPERTIES WHERE rooms = ? ORDER BY ABS(" + areaColumn + " - ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, rooms);
            pstmt.setDouble(2, area);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    properties.add(fromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return properties;
    }

    public void deleteProperty(Property property) {
        String sql = "DELETE FROM PROPERTIES WHERE address = ? AND rooms = ? AND LIVING_AREA = ? AND TOTAL_AREA = ? AND floor = ? AND price = ? AND phone = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, property.getAddress());
            stmt.setInt(2, property.getRooms());
            stmt.setDouble(3, property.getLivingArea());
            stmt.setDouble(4, property.getTotalArea());
            stmt.setInt(5, property.getFloor());
            stmt.setDouble(6, property.getPrice());
            stmt.setString(7, property.getPhone());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private Property fromResultSet(ResultSet rs) throws SQLException {
        return new Property(
                rs.getString("address"),
                rs.getInt("rooms"),
                rs.getDouble("LIVING_AREA"),
                rs.getDouble("TOTAL_AREA"),
                rs.getInt("floor"),
                rs.getDouble("price"),
                rs.getString("phone")
        );
    }
}
