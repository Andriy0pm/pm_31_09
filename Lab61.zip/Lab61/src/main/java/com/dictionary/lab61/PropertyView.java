package com.dictionary.lab61;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;

public class PropertyView {
    private final VBox root;
    private final TableView<Property> table;
    private final DatabaseManager db;

    public PropertyView() {
        db = new DatabaseManager();
        db.initDatabase(); // створюємо таблицю, якщо потрібно

        root = new VBox(10);
        root.setPadding(new Insets(10));

        table = new TableView<>();
        setupTable();
        refresh(); // завантаження з БД

        // Кнопки
        Button addBtn = new Button("Додати оголошення");
        addBtn.setOnAction(e -> {
            Property p = inputPropertyDialog();
            if (p != null) {
                db.addProperty(p);
                refresh();
            }
        });

        Button deleteBtn = new Button("Видалити");
        deleteBtn.setOnAction(e -> {
            Property selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                db.deleteProperty(selected);
                refresh();
            } else {
                showAlert("Будь ласка, виберіть оголошення для видалення.");
            }
        });

        Button searchPriceBtn = new Button("Пошук за кімнатами і ціною");
        searchPriceBtn.setOnAction(e -> {
            List<Property> results = searchByRoomsAndPriceDialog();
            if (results != null) {
                table.setItems(FXCollections.observableArrayList(results));
            }
        });

        Button searchAreaBtn = new Button("Пошук за кімнатами і площею");
        searchAreaBtn.setOnAction(e -> {
            List<Property> results = searchByRoomsAndAreaDialog();
            if (results != null) {
                table.setItems(FXCollections.observableArrayList(results));
            }
        });

        Button refreshBtn = new Button("Оновити");
        refreshBtn.setOnAction(e -> refresh());

        HBox buttons = new HBox(10, addBtn, deleteBtn, searchPriceBtn, searchAreaBtn, refreshBtn);
        root.getChildren().addAll(table, buttons);
    }

    private Property inputPropertyDialog() {
        Dialog<Property> dialog = new Dialog<>();
        dialog.setTitle("Нове оголошення");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField address = new TextField();
        TextField rooms = new TextField();
        TextField living = new TextField();
        TextField total = new TextField();
        TextField floor = new TextField();
        TextField price = new TextField();
        TextField phone = new TextField();

        grid.add(new Label("Адреса:"), 0, 0);
        grid.add(address, 1, 0);
        grid.add(new Label("Кімнат:"), 0, 1);
        grid.add(rooms, 1, 1);
        grid.add(new Label("Житлова площа:"), 0, 2);
        grid.add(living, 1, 2);
        grid.add(new Label("Загальна площа:"), 0, 3);
        grid.add(total, 1, 3);
        grid.add(new Label("Поверх:"), 0, 4);
        grid.add(floor, 1, 4);
        grid.add(new Label("Ціна:"), 0, 5);
        grid.add(price, 1, 5);
        grid.add(new Label("Телефон:"), 0, 6);
        grid.add(phone, 1, 6);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                return new Property(
                        address.getText(),
                        Integer.parseInt(rooms.getText()),
                        Double.parseDouble(living.getText()),
                        Double.parseDouble(total.getText()),
                        Integer.parseInt(floor.getText()),
                        Double.parseDouble(price.getText()),
                        phone.getText()
                );
            }
            return null;
        });

        Optional<Property> result = dialog.showAndWait();
        return result.orElse(null);
    }

    private List<Property> searchByRoomsAndPriceDialog() {
        TextInputDialog roomsDialog = new TextInputDialog();
        roomsDialog.setHeaderText("Кількість кімнат:");
        Optional<String> rooms = roomsDialog.showAndWait();

        TextInputDialog minDialog = new TextInputDialog();
        minDialog.setHeaderText("Мінімальна ціна:");
        Optional<String> min = minDialog.showAndWait();

        TextInputDialog maxDialog = new TextInputDialog();
        maxDialog.setHeaderText("Максимальна ціна:");
        Optional<String> max = maxDialog.showAndWait();

        if (rooms.isPresent() && min.isPresent() && max.isPresent()) {
            int roomCount = Integer.parseInt(rooms.get());
            double minPrice = Double.parseDouble(min.get());
            double maxPrice = Double.parseDouble(max.get());
            return db.searchByRoomsAndPrice(roomCount, minPrice, maxPrice);
        }
        return null;
    }

    private List<Property> searchByRoomsAndAreaDialog() {
        TextInputDialog roomsDialog = new TextInputDialog();
        roomsDialog.setHeaderText("Кількість кімнат:");
        Optional<String> rooms = roomsDialog.showAndWait();

        TextInputDialog approxDialog = new TextInputDialog();
        approxDialog.setHeaderText("Площа для порівняння:");
        Optional<String> approx = approxDialog.showAndWait();

        ChoiceDialog<String> typeDialog = new ChoiceDialog<>("Загальна", "Загальна", "Житлова");
        typeDialog.setHeaderText("Оберіть тип площі:");
        Optional<String> type = typeDialog.showAndWait();

        if (rooms.isPresent() && approx.isPresent() && type.isPresent()) {
            int roomCount = Integer.parseInt(rooms.get());
            double area = Double.parseDouble(approx.get());
            boolean byTotal = type.get().equals("Загальна");
            return db.searchByRoomsAndArea(roomCount, area, byTotal);
        }

        return null;
    }

    public void setupTable() {
        table.getColumns().clear();

        TableColumn<Property, String> addrCol = new TableColumn<>("Адреса");
        addrCol.setCellValueFactory(new PropertyValueFactory<>("address"));

        TableColumn<Property, Integer> roomsCol = new TableColumn<>("Кількість кімнат");
        roomsCol.setCellValueFactory(new PropertyValueFactory<>("rooms"));

        TableColumn<Property, Double> livingAreaCol = new TableColumn<>("Житлова площа");
        livingAreaCol.setCellValueFactory(new PropertyValueFactory<>("livingArea"));

        TableColumn<Property, Double> totalAreaCol = new TableColumn<>("Загальна площа");
        totalAreaCol.setCellValueFactory(new PropertyValueFactory<>("totalArea"));

        TableColumn<Property, Integer> floorCol = new TableColumn<>("Поверх");
        floorCol.setCellValueFactory(new PropertyValueFactory<>("floor"));

        TableColumn<Property, Double> priceCol = new TableColumn<>("Ціна");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Property, String> phoneCol = new TableColumn<>("Телефон");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));

        table.getColumns().addAll(addrCol, roomsCol, livingAreaCol, totalAreaCol, floorCol, priceCol, phoneCol);
    }

    public void refresh() {
        ObservableList<Property> list = FXCollections.observableArrayList(db.getAllProperties());
        table.setItems(list);
    }

    public VBox getRoot() {
        return root;
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Інформація");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
