package com.dictionary.lab61;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage primaryStage) {
        PropertyView view = new PropertyView();
        Scene scene = new Scene(view.getRoot(), 800, 600);
        primaryStage.setTitle("Real Estate Application");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}