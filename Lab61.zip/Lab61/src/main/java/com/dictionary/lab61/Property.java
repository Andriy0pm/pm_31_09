package com.dictionary.lab61;

public class Property {
    private int id; // додано для роботи з БД
    private String address;
    private int rooms;
    private double livingArea;
    private double totalArea;
    private int floor;
    private double price;
    private String phone;

    // Конструктор без id (для створення нових записів)
    public Property(String address, int rooms, double livingArea, double totalArea, int floor, double price, String phone) {
        this.address = address;
        this.rooms = rooms;
        this.livingArea = livingArea;
        this.totalArea = totalArea;
        this.floor = floor;
        this.price = price;
        this.phone = phone;
    }

    // Конструктор з id (для завантаження з БД)
    public Property(int id, String address, int rooms, double livingArea, double totalArea, int floor, double price, String phone) {
        this.id = id;
        this.address = address;
        this.rooms = rooms;
        this.livingArea = livingArea;
        this.totalArea = totalArea;
        this.floor = floor;
        this.price = price;
        this.phone = phone;
    }

    // Геттери і сеттери
    public int getId() {
        return id;
    }

    public String getAddress() {
        return address;
    }

    public int getRooms() {
        return rooms;
    }

    public double getLivingArea() {
        return livingArea;
    }

    public double getTotalArea() {
        return totalArea;
    }

    public int getFloor() {
        return floor;
    }

    public double getPrice() {
        return price;
    }

    public String getPhone() {
        return phone;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

    public void setLivingArea(double livingArea) {
        this.livingArea = livingArea;
    }

    public void setTotalArea(double totalArea) {
        this.totalArea = totalArea;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return String.format("ID: %d\nАдреса: %s\nКімнат: %d\nЖитлова площа: %.2f\nЗагальна площа: %.2f\nПоверх: %d\nЦіна: %.2f\nТелефон: %s\n",
                id, address, rooms, livingArea, totalArea, floor, price, phone);
    }
}
