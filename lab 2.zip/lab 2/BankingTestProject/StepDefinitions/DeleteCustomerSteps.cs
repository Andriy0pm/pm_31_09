﻿using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using BankingTestProject.Pages;

[Binding]
public class DeleteCustomerSteps
{
    private IWebDriver driver;
    private LoginPage loginPage;
    private BankManagerPage bankManagerPage;
    private CustomersPage customersPage;

    [BeforeScenario]
    public void Setup()
    {
        DriverFactory.InitDriver();
        driver = DriverFactory.Driver;
        loginPage = new LoginPage(driver);
        bankManagerPage = new BankManagerPage(driver);
        customersPage = new CustomersPage(driver);
    }

    [AfterScenario]
    public void TearDown() => DriverFactory.QuitDriver();

    [Given(@"the bank manager is on the login page")]
    public void GivenTheBankManagerIsOnTheLoginPage()
    {
        loginPage.GoTo();
    }

    [When(@"the manager logs in to the system")]
    public void WhenTheManagerLogsInToTheSystem()
    {
        loginPage.ClickBankManagerLogin();
    }

    [When(@"navigates to the ""(.*)"" section")]
    public void WhenNavigatesToTheSection(string section)
    {
        if (section == "Customers")
            bankManagerPage.GoToCustomers();
    }

    [When(@"searches for a customer with name ""(.*)""")]
    public void WhenSearchesForACustomerWithName(string name)
    {
        customersPage.SearchCustomer(name);
        ///Thread.Sleep(20000);
    }

    [When(@"deletes a customer with name ""(.*)""")]
    public void WhenDeletesACustomerWithName(string name)
    {
        Thread.Sleep(5000);
        customersPage.DeleteCustomer(name);
        Thread.Sleep(5000);
    }

    [Then(@"the customer ""(.*)"" should no longer be in the list")]
    public void ThenTheCustomerShouldNoLongerBeInTheList(string name)
    {
        Assert.IsFalse(customersPage.IsCustomerPresent(name), $"Customer {name} was not deleted.");
    }
}
