﻿using OpenQA.Selenium;
using OpenQA.Selenium.Edge;

public static class DriverFactory
{
    public static IWebDriver Driver { get; private set; }

    public static void InitDriver()
    {
        var options = new EdgeOptions();
        //options.UseChromium = true;
        Driver = new EdgeDriver(options);
        Driver.Manage().Window.Maximize();
    }

    public static void QuitDriver()
    {
        Driver.Quit();
    }
}
