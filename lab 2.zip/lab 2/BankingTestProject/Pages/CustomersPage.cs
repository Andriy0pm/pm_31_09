﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Linq;
using SeleniumExtras.WaitHelpers;

namespace BankingTestProject.Pages
{
    public class CustomersPage
    {
        private readonly IWebDriver driver;
        private readonly WebDriverWait wait;

        public CustomersPage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
        }

        public void SearchCustomer(string name)
        {
            // Очікування на появу поля пошуку
            var searchInput = wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("input[ng-model='searchCustomer']")));
            searchInput.Clear();
            searchInput.SendKeys(name);
        }

        public void DeleteCustomer(string name)
        {
            // Очікуємо, поки таблиця з клієнтами завантажиться
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//table/tbody")));

            var rows = driver.FindElements(By.XPath("//table/tbody/tr"));

            foreach (var row in rows)
            {
                if (row.Text.Contains(name))
                {
                    // Явне очікування кнопки Delete в потрібному рядку
                    var deleteButton = wait.Until(d =>
                    {
                        try
                        {
                            return row.FindElement(By.CssSelector("button"));
                        }
                        catch (NoSuchElementException)
                        {
                            return null;
                        }
                    });

                    deleteButton?.Click();
                    break;
                }
            }
        }

        public bool IsCustomerPresent(string name)
        {
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//table/tbody")));
            var rows = driver.FindElements(By.XPath("//table/tbody/tr"));
            return rows.Any(row => row.Text.Contains(name));
        }
    }
}
