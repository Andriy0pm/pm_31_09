﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace BankingTestProject.Pages
{
    public class BankManagerPage
    {
        private IWebDriver driver;

        public BankManagerPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        // Онови селектор на актуальний
        private By customersButtonSelector = By.CssSelector("button[ng-click='showCust()']"); // або інший правильний селектор

        public void GoToCustomers()
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
            var customersButton = wait.Until(ExpectedConditions.ElementToBeClickable(customersButtonSelector));
            customersButton.Click();
        }
    }
}
