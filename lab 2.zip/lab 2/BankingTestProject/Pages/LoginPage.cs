﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;  // Потрібен для ExpectedConditions

namespace BankingTestProject.Pages
{
    public class LoginPage
    {
        private IWebDriver driver;

        public LoginPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void GoTo()
        {
            driver.Navigate().GoToUrl("https://www.globalsqa.com/angularJs-protractor/BankingProject/");
        }

        // Метод з очікуванням клікабельності кнопки
        public void ClickBankManagerLogin()
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(15));
            var button = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("button[ng-click='manager()']")));
            button.Click();
        }
    }
}
